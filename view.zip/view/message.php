<div id="POPUP_SUCCESS" class="POPUP" style="background-color: rgba(0,0,0,0.5);position: fixed;width: 100%;height: 100%;top: 0;left: 0;z-index: 1050;display: none;">
	<div style="background-color: white;width: 400px;height: 90px;margin: auto;margin-top: 3%;border-radius: 5px;box-shadow: 0 0 20px black;padding: 10px 20px;text-align: center;border-left: 20px solid lime;">
		<div style="width: 100%;"><a style="float: right;cursor: pointer;" onclick="closePopup()">x</a></div><br>
		<div id="POPUP_SUCCESS_TXT"></div>
	</div>
</div>
<div id="POPUP_ALERT" class="POPUP" style="background-color: rgba(0,0,0,0.5);position: fixed;width: 100%;height: 100%;top: 0;left: 0;z-index: 1050;display: none;">
	<div style="background-color: white;width: 400px;height: 90px;margin: auto;margin-top: 3%;border-radius: 5px;box-shadow: 0 0 20px black;padding: 10px 20px;text-align: center;border-left: 20px solid red;">
		<div style="width: 100%;"><a style="float: right;cursor: pointer;" onclick="closePopup()">x</a></div><br>
		<div id="POPUP_ALERT_TXT"></div>
	</div>
</div>

<script type="text/javascript">
function closePopup() {
	var x = document.getElementsByClassName('POPUP');
	for (var i = x.length - 1; i >= 0; i--) {
		x[i].style.display = "none";
	}
}
</script>