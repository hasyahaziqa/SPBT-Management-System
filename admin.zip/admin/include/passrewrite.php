<?php 
	$one = $password;
	$two = '8iaDY81dGY68ADLI34hFJ639IK73jks7JFSW94a';
	$thr = $two.$one.$two.$two;
	$fou = hash('sha512', $thr);
	$fiv = md5($fou);
	$password = $fiv;